package br.com.fernando.models;

public class Funcionario extends Pessoa{

    private String perfil;
    private int matricula;
}
