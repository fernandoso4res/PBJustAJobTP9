package br.com.fernando.models;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Agenda {
    private List<Date> diasDeTrabalho;

    public Agenda(List<Date> diasDeTrabalho){
        this.diasDeTrabalho = diasDeTrabalho;
    }

    public ArrayList<Date> verificarDatasDisponiveis(){
        throw new NotImplementedException();
    }

    public boolean visualizarDisponibilidadeData(Date data){
        throw new NotImplementedException();
    }

    public List<Date> visualizarCompromissos(){
        throw new NotImplementedException();
    }

    public Funcionario visualizarFuncionario(Pessoa pessoa){
        throw new NotImplementedException();
    }

    public List<Funcionario> visualizarFuncionarios(List<Pessoa> pessoa){
        throw new NotImplementedException();
    }
}
