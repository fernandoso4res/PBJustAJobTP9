package br.com.fernando.models;

public class Imovel {

    private Cliente cliente;
    private String Logradouro;
    private String numero;
    private String complemento;
    private String bairro;
    private String cidade;
    private String estado;
    private int cep;

    public Imovel(){

    }

    public Imovel(Cliente cliente, String logradouro, String numero, String complemento, String bairro, String cidade, String estado, int cep) {
        this.cliente = cliente;
        Logradouro = logradouro;
        this.numero = numero;
        this.complemento = complemento;
        this.bairro = bairro;
        this.cidade = cidade;
        this.estado = estado;
        this.cep = cep;
    }
}
